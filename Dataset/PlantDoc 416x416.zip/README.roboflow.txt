
PlantDoc - v1 resize-416x416
==============================

This dataset was exported via roboflow.ai on March 9, 2020 at 1:31 PM GMT

It includes 2569 images.
Leaves are annotated with bounding boxes in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


